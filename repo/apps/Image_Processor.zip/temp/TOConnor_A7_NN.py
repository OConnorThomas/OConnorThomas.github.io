import numpy as np
import pickle
from keras import utils
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from keras.callbacks import EarlyStopping
import matplotlib.pyplot as plt

# Function to unpickle data
def unpickle(file):
    with open(file, 'rb') as fo:
        dict = pickle.load(fo, encoding='bytes')
    return dict

# Load training data
batches = []
for i in range(1, 6):
    batch = unpickle(f'data/batches/data_batch_{i}')
    batches.append(batch)
    
# Combine batches
train_images = np.concatenate([batch[b'data'] for batch in batches], axis=0)
train_labels = np.concatenate([batch[b'labels'] for batch in batches], axis=0)

# Load test data
test_batch = unpickle('data/batches/test_batch')
test_images = test_batch[b'data']
test_labels = test_batch[b'labels']

# Load label names
label_names = unpickle('data/batches/batches.meta')[b'label_names']

# Preprocess data
train_images = train_images.reshape(-1, 3, 32, 32).transpose(0, 2, 3, 1) / 255.0
test_images = test_images.reshape(-1, 3, 32, 32).transpose(0, 2, 3, 1) / 255.0

# Convert labels to categorical
train_labels = utils.to_categorical(train_labels, num_classes=10)
test_labels = utils.to_categorical(test_labels, num_classes=10)

# Define CNN architecture
model = Sequential([
    Conv2D(32, (3, 3), activation='relu', input_shape=(32, 32, 3)),
    MaxPooling2D((2, 2)),
    Conv2D(64, (3, 3), activation='relu'),
    MaxPooling2D((2, 2)),
    Conv2D(64, (3, 3), activation='relu'),
    Flatten(),
    Dense(64, activation='relu'),
    Dropout(0.5),
    Dense(10, activation='softmax')
])

# Compile model
model.compile(optimizer='adam',
              loss='categorical_crossentropy',
              metrics=['accuracy'])

# Define early stopping
early_stopping = EarlyStopping(monitor='val_loss', patience=3, restore_best_weights=True)

# Train the model
history = model.fit(train_images, train_labels, epochs=20, batch_size=128, 
                    validation_split=0.2, callbacks=[early_stopping])

# Plot training and validation accuracy
plt.plot(history.history['accuracy'], label='Training Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()
plt.savefig('training_validation_acc.png')
plt.close()

# Plot training and validation loss
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()
plt.savefig('training_validation_loss.png')
plt.close()

# Evaluate model on test set
test_loss, test_acc = model.evaluate(test_images, test_labels)
print(f'Test Accuracy: {test_acc:.4f}')

# Display a few images from the test set with predictions
predictions = model.predict(test_images)
num_images_to_display = 5

for i in range(num_images_to_display):
    plt.imshow(test_images[i])
    plt.title(f'Actual: {label_names[test_labels[i].argmax()]}, Predicted: {label_names[predictions[i].argmax()]}')
    plt.axis('off')
    plt.savefig(f'image_{i+1}.png')
    plt.close()
