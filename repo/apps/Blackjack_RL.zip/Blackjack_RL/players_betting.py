from enum import Enum
from players import PlayerAction

def format_amount(amount):
    if amount.is_integer():
        return int(amount)
    else:
        return round(amount, 2)

class Player:
    def __init__(self, player_num=0, balance=0, is_dealer=False):
        self.player_num = player_num
        self.balance = round(balance, 2)
        self.bet_value = [0]
        self.insurance_bet = None

        self.card_list = [[]]
        self.card_sum = [0]
        self.current_hand_index = 0
        self.num_hands = 1
        self.history = []

        # Hand-specific attribute flags
        self.hand_flags = [{
            'is_blackjack': False,
            'is_surrendered': False,
            'is_won': False,
            'is_lost': False,
            'is_push': False,
            'ins_won': False
        }]
        self.is_dealer = is_dealer

    def reset(self):
        self.bet_value = [0]
        self.insurance_bet = None
        self.card_list = [[]]
        self.card_sum = [0]
        self.current_hand_index = 0
        self.num_hands = 1
        self.history = []
        self.hand_flags = [{
            'is_blackjack': False,
            'is_surrendered': False,
            'is_won': False,
            'is_lost': False,
            'is_push': False,
            'ins_won': False
        }]

    def set_balance(self, account_balance):
        self.balance = round(account_balance, 2)

    def place_bet(self, amount):
        amount = round(amount, 2)
        if amount > self.balance:
            raise ValueError("Insufficient balance")
        if amount < 0:
            raise ValueError("Cannot request negative balance")
        self.bet_value[self.current_hand_index] = amount
        self.balance -= amount

    def place_insurance_bet(self, amount):
        amount = round(amount, 2)
        if amount > self.balance:
            raise ValueError("Insufficient balance")
        if amount < 0:
            raise ValueError("Cannot request negative balance")
        if amount > self.bet_value[0]/2:
            raise ValueError('Cannot bet more than half of original bet value')
        self.insurance_bet = amount
        self.balance -= amount
        self.balance = round(self.balance, 2)

    def add_card(self, card):
        self.card_list[self.current_hand_index].append(card)
        self.update_card_sum()

    def update_card_sum(self, cards=None): # manually pass cards for partial hand sums partial_sum()
        value_map = {
            'A': 11, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'X': 10,
            'J': 10, 'Q': 10, 'K': 10
        }
        total = 0
        aces = 0

        if not cards:
            cards = self.card_list[self.current_hand_index]

        for card in cards:
            value = card[:-1]
            total += value_map[value]
            if value == 'A':
                aces += 1

        # Adjust for Aces
        while total > 21 and aces:
            total -= 10
            aces -= 1

        self.card_sum[self.current_hand_index] = total
        return total
    
    def partial_sum(self, num_cards):
        if num_cards > len(self.card_list[self.current_hand_index]):
            raise ValueError("num_cards is greater than the number of cards in hand.")
        partial = self.update_card_sum(self.card_list[self.current_hand_index][:num_cards])
        self.update_card_sum() # update real card sum internally for consistency
        return partial

    def is_bust(self):
        return self.card_sum[self.current_hand_index] > 21
    
    def split_hand(self, dealt_card_one, dealt_card_two):
        # take the existing set of cards
        existing_hand = self.card_list[self.current_hand_index]
        
        first_hand = [existing_hand[0], dealt_card_one]
        second_hand = [existing_hand[1], dealt_card_two]

        # divide them and splice them with provided cards from dealer
        self.card_list[self.current_hand_index] =  first_hand
        self.card_list.insert(self.current_hand_index+1, second_hand)

        # update new hand
        self.bet_value.insert(self.current_hand_index+1, self.bet_value[self.current_hand_index])
        self.balance -= self.bet_value[self.current_hand_index]

        # update old hand
        self.update_card_sum()

        # update new hand
        self.num_hands += 1
        self.card_sum.insert(self.current_hand_index+1, 0)
        self.current_hand_index += 1
        self.update_card_sum()

        # return to old hand
        self.current_hand_index -= 1

        self.hand_flags.insert(self.current_hand_index+1, {
            'is_blackjack': False,
            'is_surrendered': False,
            'is_won': False,
            'is_lost': False,
            'is_push': False,
            'ins_won': False
        })

    def set_flag(self, flag):
        self.hand_flags[self.current_hand_index][flag] = True

    def get_flag(self, flag):
        return self.hand_flags[self.current_hand_index][flag]
    
    def get_reserve_aces(self):
        
        value_map = { # ace default to 1 assumed
            'A': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'X': 10,
            'J': 10, 'Q': 10, 'K': 10
        }
        base_total = 0
        aces = False
        
        # Count aces and sum up non-ace cards
        for card in self.card_list[self.current_hand_index]:
            value = card[:-1]
            if value == 'A':
                aces = True
            base_total += value_map[value]
        
        return 1 if aces and base_total + 10 <= 21 else 0
    
    def can_split(self):
        return self.card_list[self.current_hand_index][0][0] == self.card_list[self.current_hand_index][1][0] and len(self.card_list[self.current_hand_index]) == 2 and self.balance >= self.bet_value[self.current_hand_index]
    
    def can_dd(self):
        return self.balance >= self.bet_value[self.current_hand_index] and len(self.card_list[self.current_hand_index]) == 2

    def get_available_actions(self):
        base_actions = [PlayerAction.STAND, PlayerAction.HIT, PlayerAction.SURRENDER]
        if self.can_split(): 
            base_actions += [PlayerAction.SPLIT]
        if self.can_dd():
            base_actions += [PlayerAction.DOUBLE_DOWN]
        return base_actions
    
    def double_down_bet(self):
        self.balance -= self.bet_value[self.current_hand_index]
        self.bet_value[self.current_hand_index] += self.bet_value[self.current_hand_index]
        self.bet_value[self.current_hand_index] = round(self.bet_value[self.current_hand_index], 2)
    
    def win_blackjack(self):
        self.balance += round(self.bet_value[self.current_hand_index] * 2.5, 2)

    def win(self):
        self.balance += round(self.bet_value[self.current_hand_index] * 2, 2)
        self.set_flag('is_won')

    def win_insurance(self):
        self.balance += round(self.insurance_bet * 3, 2)
        self.set_flag('ins_won') # won insurance
        if not self.get_flag('is_push'): # blackjack already pushed
            self.set_flag('is_lost') # lost main hand

    def loss(self):
        self.set_flag('is_lost')

    def push(self):
        self.balance += self.bet_value[self.current_hand_index]
        self.set_flag('is_push')

    def surrender(self):
        self.bet_value[self.current_hand_index] = round(self.bet_value[self.current_hand_index] / 2, 2)
        self.balance += self.bet_value[self.current_hand_index]
        self.set_flag('is_surrendered')

    def clear_bet(self):
        self.bet_value[self.current_hand_index] = 0

    def get_outcome(self):
        if self.get_flag('is_blackjack'):
            return "Blackjack"
        elif self.get_flag('is_surrendered'):
            return "Surrendered"
        elif self.get_flag('is_won'):
            return "Won"
        elif self.get_flag('is_lost'):
            return "Lost"
        elif self.get_flag('is_push'):
            return "Push"
        else:
            return "No outcome determined ERROR"
    
    # for logging 
    def get_hand(self):
        if not self.is_dealer:
            hands = []
            for i in range(self.num_hands):
                self.current_hand_index = i
                hand_data = {
                    "hand_id": i + 1,
                    "cards": [card for card in self.card_list[i]],
                    "sum": self.card_sum[i],
                    "outcome": self.get_outcome()
                }
                hands.append(hand_data)
            # Reset current hand index after checking outcome
            self.current_hand_index = 0
            return {
                "insurance_bet": self.insurance_bet if self.insurance_bet else None,
                "hands": hands
            }
        else:  # Dealer hand
            return {
                "dealer_hand": {
                    "cards": [str(card) for card in self.card_list[0]],
                    "sum": self.card_sum[0]
                }
            }



    def __str__(self):
        signs = {
            "Blackjack": '+',
            "Surrendered": '-',
            "Won": '+',
            "Lost": '-',
            "Push": ' ',
        }

        result = ''

        self.current_hand_index = 0
        
        win_coef = 1.5 if self.get_flag('is_blackjack') else 1
        
        if self.num_hands > 1:
            while self.current_hand_index < self.num_hands:
                win_coef = 1.5 if self.get_flag('is_blackjack') else 1
                result += (
                    f"Hand {self.current_hand_index + 1} | Bet Value: {format_amount(self.bet_value[self.current_hand_index])},"
                    f"Outcome: {self.get_outcome()} | {signs[self.get_outcome()]}{format_amount(self.bet_value[self.current_hand_index] * win_coef)},"
                    f"Cards: {' '.join(self.card_list[self.current_hand_index])} | Sum: {self.card_sum[self.current_hand_index]},," # double comma for newline
                )
                self.current_hand_index += 1
            self.current_hand_index = 0
        else: # single hand
            result += (
                f"Bet Value: {format_amount(self.bet_value[self.current_hand_index])},"
                f"Outcome: {self.get_outcome()} | {signs[self.get_outcome()]}{format_amount(self.bet_value[self.current_hand_index] * win_coef)},"
                f"Cards: {' '.join(self.card_list[self.current_hand_index])} | Sum: {self.card_sum[self.current_hand_index]},," # double comma for newline
            )
        if self.insurance_bet: # insurance bet exists only when collected
            if self.get_flag('ins_won'):
                result += (
                    f"Insurance: {format_amount(self.insurance_bet)},"
                    f"Outcome: Won +{format_amount(self.insurance_bet*2)} on {format_amount(self.insurance_bet)},," # double comma for newline
                )
            else: # ins_lost
                result += (
                    f"  Insurance: {format_amount(self.insurance_bet)},"
                    f"  Outcome: Lost -{format_amount(self.insurance_bet)},," # double comma for newline
                )

        result += f"Balance:   {format_amount(self.balance)}"
        return result


class Dealer(Player):
    def __init__(self):
        super().__init__(is_dealer=True)


    def should_hit(self):
        return self.card_sum[0] < 17

    def check_possible_blackjack(self):
        return self.card_list[0][0][0] in ['A', 'X', 'J', 'Q', 'K']
    
    def check_ace_card(self):
        return self.card_list[0][0][0] == 'A'

    def has_blackjack(self):
        return (self.update_card_sum() == 21) and (len(self.card_list[0]) == 2)
