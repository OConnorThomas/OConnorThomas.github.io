import json
import os
import random
from players import PlayerAction


# === File Constants ===
MODEL_PATH = 'model'
TABLE_FILE = os.path.join(MODEL_PATH, 'blackjack_lookup_table.json')
explore_coeff_start, explore_coeff_min = 0.20, 0.08
# decay_rate = 2e-7
decay_rate = 10e-8

# === Singleton Lookup Table Manager ===
class LookupTableManager:
    _instance = None
    _table = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(LookupTableManager, cls).__new__(cls)
            cls._instance._load_table()
        return cls._instance

    def _load_table(self):
        if not os.path.exists(MODEL_PATH):
            os.mkdir(MODEL_PATH)
        if not os.path.exists(TABLE_FILE):
            self._table = self._initialize_table()
            self.save_table()
        else:
            with open(TABLE_FILE, 'r') as f:
                self._table = json.load(f)

    def _initialize_table(self):
        results = ['is_21', 'is_lost', 'is_under', 'is_won']
        actions = ['n', 'h', 'd']

        action_results = {action: {result: 0 for result in results} for action in actions}
        table = {}
        dealer_values = ['A', '2', '3', '4', '5', '6', '7', '8', '9', 'X']
        for dealer_card in dealer_values:
            table[dealer_card] = {}
            for total in range(4, 21):
                table[dealer_card][str(total)] = {}
                for num_reserve_aces in range(0, 2):
                    table[dealer_card][str(total)][str(num_reserve_aces)] = json.loads(json.dumps(action_results))
        return table

    def save_table(self):
        with open(TABLE_FILE, 'w') as f:
            json.dump(self._table, f, indent=2)

    def get_state_data(self, dealer_card, total, num_reserve_aces):
        return self._table[dealer_card][str(total)][str(num_reserve_aces)]

    def update_state(self, dealer_card, total, num_reserve_aces, action_taken, action_result):
        self._table[dealer_card][str(total)][str(num_reserve_aces)][action_taken.value][action_result] += 1
        if action_taken == PlayerAction.DOUBLE_DOWN:
            self._table[dealer_card][str(total)][str(num_reserve_aces)][action_taken.value][action_result] += 1
        return


# === Core Functions ===

# Annealing
def get_exploration_rate(game_number):
    """Return annealed exploration rate based on the current game number."""
    return max(explore_coeff_min, explore_coeff_start * (1 - decay_rate) ** game_number)


def get_table_action(dealer_face_card_value, player_card_sum, player_reserve_aces, available_actions, game_num=0, explore=True):
    """
    Selects the action with the highest point total from the reward map.
    """
    
    # Static split logic
    if PlayerAction.SPLIT in available_actions:
    
        char_to_int = {'A': 11, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'X': 10}
        dealer_showing_num = char_to_int[dealer_face_card_value]

        if player_reserve_aces and player_card_sum == 12 or player_card_sum == 16:
            return PlayerAction.SPLIT
        elif dealer_showing_num in range(2, 8) and player_card_sum in [4, 6, 14]:
            return PlayerAction.SPLIT
        elif dealer_showing_num in [5, 6] and player_card_sum == 8:
            return PlayerAction.SPLIT
        elif dealer_showing_num in range(2, 7) and player_card_sum == 12:
            return PlayerAction.SPLIT
        elif (dealer_showing_num in range(2, 7) or dealer_showing_num in [8, 9]) and player_card_sum == 18:
            return PlayerAction.SPLIT
        else:
            available_actions.remove(PlayerAction.SPLIT)

    # Access the lookup table from memory
    table_manager = LookupTableManager()
    state_data = table_manager.get_state_data(dealer_face_card_value, player_card_sum, player_reserve_aces)

    # Compute win percentages for each action
    action_win_pct_list = []
    for action, result_counts in state_data.items():
        win_count = (result_counts.get('is_21', 0) * 0.5) + result_counts.get('is_won', 0) + (result_counts.get('is_under', 0) * 0.3)
        loss_count = result_counts.get('is_lost', 0)
        total_count = win_count + loss_count
        win_pct = (win_count / total_count) if total_count > 0 else -1
        action_win_pct_list.append((action, win_pct))

    # Sort actions by win percentage in descending order
    action_win_pct_list.sort(key=lambda x: x[1], reverse=True)

    # Select the best action based on highest win percentage
    best_action = PlayerAction(action_win_pct_list[0][0]) if action_win_pct_list else PlayerAction(random.choice(available_actions))

    # Exploration step
    if explore:
        if random.uniform(0, 1) < get_exploration_rate(game_num):
            best_action = PlayerAction(random.choice(available_actions))

    return best_action

def update_table(dealer_face_card_value, player_card_sum, player_reserve_aces, action_taken, action_result):
    """
    Updates the lookup table by incrementing the count for the specified action_result in memory.
    """
    table_manager = LookupTableManager()
    table_manager.update_state(dealer_face_card_value, player_card_sum, player_reserve_aces, action_taken, action_result)


# manual query interface helpers

def get_valid_dealer_card():
    """Ensures dealer's visible card is valid."""
    valid_cards = {'A', '2', '3', '4', '5', '6', '7', '8', '9', 'X'}
    while True:
        card = input("Dealer's Visible Card [A, 2, 3... 9, X]: ").strip().upper()
        if card in valid_cards:
            return card
        print("Invalid input! Please enter A, 2-9, or X (for 10, J, Q, K).")

def get_valid_int(prompt, valid_range):
    """Ensures user input is an integer within a valid range."""
    while True:
        try:
            value = int(input(prompt).strip())
            if value in valid_range:
                return value
            print(f"Invalid input! Enter a number in {valid_range}.")
        except ValueError:
            print("Invalid input! Please enter a valid number.")

from colorama import Fore, Style

if __name__ == "__main__":

    print(f"\033[1m{Fore.BLUE}Blackjack {Fore.GREEN}Decision {Fore.YELLOW}Assistant{Style.RESET_ALL}\n")
    
    while True:
        try:
            dealer_face_card_value = get_valid_dealer_card()

            player_card_sum = get_valid_int("Player Card Sum [4-20]: ", range(4, 21))

            # number of aces as an 11 (reserve down to 1)
            if player_card_sum > 11:
                reserve_aces = get_valid_int("Number of Aces represented as 11 [0, 1]: ", {0, 1})
            else: # sum below 12, no reserve aces possible
                reserve_aces = 0

            if (player_card_sum == 12 and reserve_aces == 1) or (player_card_sum == 4):
                # case for 2 aces, 2 2's: split and dd guarunteed
                can_split = 1
                can_dd = 1
            elif (player_card_sum % 2 == 0 and player_card_sum != 12 and not reserve_aces):
                # sum even, not a pair of aces, not including an ace
                can_split = get_valid_int("Can you split? [0, 1]: ", {0, 1}) == 1
            else: # sum odd, no splits possible
                can_split = 0
                
            if not ((player_card_sum == 12 and reserve_aces == 1) or (player_card_sum == 4)):
                # case for not 2 aces, not 2 2's where dd not guarunteed
                can_dd = get_valid_int("Can you double down? [0, 1]: ", {0, 1}) == 1

            base_actions = [PlayerAction.STAND, PlayerAction.HIT]
            if can_split:
                base_actions.append(PlayerAction.SPLIT)
            if can_dd:
                base_actions.append(PlayerAction.DOUBLE_DOWN)

            chosen_action = get_table_action(dealer_face_card_value, player_card_sum, reserve_aces, base_actions, explore=False)
            
            print(f'Based on the state of play, the recommended action is: \033[1m{chosen_action.colored_name()}\n')

        except KeyboardInterrupt:
            print(f"\n\033[1m{Fore.BLUE}Blackjack {Fore.GREEN}Decision {Fore.YELLOW}Assistant{Style.RESET_ALL} Exiting. Goodbye!")
            break