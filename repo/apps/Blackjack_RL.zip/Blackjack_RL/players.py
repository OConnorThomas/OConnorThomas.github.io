from enum import Enum
from colorama import Fore, Style, init

# Initialize colorama for Windows compatibility
init(autoreset=True)

class PlayerAction(Enum):
    STAND = 'n'
    HIT = 'h'
    SPLIT = 's'
    DOUBLE_DOWN = 'd'
    SURRENDER = 'c'

    @classmethod
    def from_input(cls, input_value, can_split, can_dd):
        """Convert user input into a PlayerAction enum."""
        if input_value in ['0', 'n', 'stand']:
            return cls.STAND
        elif input_value in ['1', 'h', 'y', 'hit']:
            return cls.HIT
        elif input_value in ['2', 's', 'split'] and can_split:
            return cls.SPLIT
        elif input_value in ['3', 'd', 'dd', 'double down', 'double-down'] and can_dd:
            return cls.DOUBLE_DOWN
        elif input_value in ['4', 'c', 'cancel', 'forfeit', 'surrender']:
            return cls.SURRENDER
        else:
            raise ValueError("Invalid input")
    
    @property
    def color(self):
        """Returns the color associated with the action."""
        action_colors = {
            'n': Fore.BLUE,
            'h': Fore.GREEN,
            's': Fore.MAGENTA,
            'd': Fore.YELLOW,
            'c': Fore.RED
        }
        return action_colors[self.value]

    def colored_name(self):
        """Returns the colored action name for terminal output."""
        return self.color + self.name + Style.RESET_ALL


class Player:
    def __init__(self, player_num=0, is_dealer=False):
        self.player_num = player_num
        self.is_dealer = is_dealer

        self.card_list = [[]]
        self.card_sum = [0]
        self.current_hand_index = 0
        self.num_hands = 1

        # algo features
        self.states = [[()]]

    def reset(self):
        self.card_list = [[]]
        self.card_sum = [0]
        self.current_hand_index = 0
        self.num_hands = 1

        # algo features
        self.states = [[()]]

    def add_card(self, card):
        self.card_list[self.current_hand_index].append(card)
        self.update_card_sum()

    def update_card_sum(self):
        value_map = {
            'A': 11, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'X': 10,
            'J': 10, 'Q': 10, 'K': 10
        }
        total = 0
        aces = 0

        for card in self.card_list[self.current_hand_index]:
            value = card[:-1]
            total += value_map[value]
            if value == 'A':
                aces += 1

        # Adjust for Aces
        while total > 21 and aces:
            total -= 10
            aces -= 1

        self.card_sum[self.current_hand_index] = total
        return total

    def is_bust(self):
        return self.card_sum[self.current_hand_index] > 21
    
    def split_hand(self, dealt_card_one, dealt_card_two):
        # take the existing set of cards
        existing_hand = self.card_list[self.current_hand_index]
        
        first_hand = [existing_hand[0], dealt_card_one]
        second_hand = [existing_hand[1], dealt_card_two]

        # divide them and splice them with provided cards from dealer
        self.card_list[self.current_hand_index] =  first_hand
        self.card_list.insert(self.current_hand_index+1, second_hand)

        # update old hand
        self.update_card_sum()

        # update new hand
        self.num_hands += 1
        self.card_sum.insert(self.current_hand_index+1, 0)
        self.current_hand_index += 1
        self.update_card_sum()

        # return to old hand
        self.current_hand_index -= 1

        self.states[self.current_hand_index] = [()] # overwrite previous split action: static logic; ignore
        self.states.insert(self.current_hand_index+1, [()])
    
    def can_split(self):
        return self.card_list[self.current_hand_index][0][0] == self.card_list[self.current_hand_index][1][0] and self.can_dd()
    
    def can_dd(self):
        return len(self.card_list[self.current_hand_index]) == 2

    def get_available_actions(self):
        base_actions = [PlayerAction.STAND, PlayerAction.HIT]
        if self.can_split(): 
            base_actions += [PlayerAction.SPLIT]
        if self.can_dd():
            base_actions += [PlayerAction.DOUBLE_DOWN]
        return base_actions

    def get_reserve_aces(self):
        
        value_map = { # ace default to 1 assumed
            'A': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'X': 10,
            'J': 10, 'Q': 10, 'K': 10
        }
        base_total = 0
        aces = False
        
        # Count aces and sum up non-ace cards
        for card in self.card_list[self.current_hand_index]:
            value = card[:-1]
            if value == 'A':
                aces = True
            base_total += value_map[value]
        
        return 1 if aces and base_total + 10 <= 21 else 0



class Dealer(Player):
    def __init__(self):
        super().__init__(is_dealer=True)

    def should_hit(self):
        return self.card_sum[0] < 17

    def has_blackjack(self):
        return (self.update_card_sum() == 21) and (len(self.card_list[0]) == 2)
