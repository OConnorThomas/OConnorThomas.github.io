import random
import shutil  # terminal centering
import os
import time
import json
from enum import Enum
import re

from players_betting import Player, Dealer
from players import PlayerAction
from algo import get_table_action, get_all_actions, LookupTableManager

class ListError(Exception):
    def __init__(self, messages):
        if not isinstance(messages, list):
            raise TypeError("messages must be a list of strings")
        self.messages = messages
        super().__init__(self.messages)  # Pass list for potential debugging

    def __str__(self):
        return "\n".join(self.messages)  # Join with newlines for string output

values = ('A', '2', '3', '4', '5', '6', '7', '8', '9', 'X', 'J', 'Q', 'K')
suits = ('H', 'D', 'S', 'C')

def clear_screen():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')

def move_cursor(row, col):
    print(f"\033[{row};{col}H", end='')

def format_amount(amount):
    if amount.is_integer():
        return int(amount)
    else:
        return amount

def strip_ansi(text):
    """Remove ANSI escape codes from text for correct length calculations."""
    ansi_escape = re.compile(r'\033\[[0-9;]*m')
    return ansi_escape.sub('', text)

def print_centered(text, width=None):
    if width is None:
        width = shutil.get_terminal_size().columns

    # Strip ANSI codes for length calculation but preserve the original text
    clean_text = strip_ansi(text)
    
    # Calculate the padding required to center the text
    padding_left = (width - len(clean_text)) // 2
    padding_right = (width - len(clean_text) + 1) // 2
    
    # Print the text with correct padding, preserving ANSI escape codes
    print(f"{' ' * padding_left}{text}{' ' * padding_right}")

def print_prompt_centered(text, width=None, end='', right_pad=1):
    if width is None:
        width = shutil.get_terminal_size().columns
    text_less_trailing_whitespace = text.center(width).rstrip() + (' ' * right_pad)
    print(text_less_trailing_whitespace, end=end)

def generate_card_lines(card_type):
    card_names = {
        'A': 'Ace',
        '2': 'Two',
        '3': 'Three',
        '4': 'Four',
        '5': 'Five',
        '6': 'Six',
        '7': 'Seven',
        '8': 'Eight',
        '9': 'Nine',
        'X': 'Ten',
        'J': 'Jack',
        'Q': 'Queen',
        'K': 'King',
        ' ': ''
    }
    
    suits = {
        'S': 'Spades',
        'H': 'Hearts',
        'D': 'Diamonds',
        'C': 'Clubs',
        ' ': ''
    }

    suit_char_refs = {
        'S': '♠',
        'H': '♥',
        'D': '♦',
        'C': '♣',
        ' ': ' '
    }

    # fancy blank card
    if card_type == '  ':
        return [
            '╔═╤══╤══╤══╤══╤══╤═╗',
            '║ ╰╮ ╰╮ ╰╮ ╰╮ ╰╮ ╰╮║',
            '╟╮ ╰╮ ╰╮ ╰╮ ╰╮ ╰╮ ╰╢',
            '║╰╮ ╰╮ ╰╮ ╰╮ ╰╮ ╰╮ ║',
            '║ ╰╮ ╰╮ ╰╮ ╰╮ ╰╮ ╰╮║',
            '╟╮ ╰╮ ╰╮ ╰╮ ╰╮ ╰╮ ╰╢',
            '║╰╮ ╰╮ ╰╮ ╰╮ ╰╮ ╰╮ ║',
            '║ ╰╮ ╰╮ ╰╮ ╰╮ ╰╮ ╰╮║',
            '╟╮ ╰╮ ╰╮ ╰╮ ╰╮ ╰╮ ╰╢',
            '║╰╮ ╰╮ ╰╮ ╰╮ ╰╮ ╰╮ ║',
            '╚═╧══╧══╧══╧══╧══╧═╝'
        ]
    
    value = card_type[:-1]  # Get all characters except the last one
    suit = card_type[-1]  # Get the last character

    full_name = f"{card_names.get(value, value)} of {suits.get(suit, '')}" if value != ' ' else ''
    width = 20  # Total width of the card including borders
    name_padding = (width - 2 - len(full_name)) // 2  # Calculate padding for centering the name

    if (width - 2 - len(full_name)) % 2 != 0:
        full_name = full_name + ' '

    suit_char = suit_char_refs.get(suit, '')

    card_lines = [
        f"╔{'═' * (width - 2)}╗",
        f"║ {card_type}{' ' * (width - 7)}{suit_char} ║",
        f"║{' ' * (width - 2)}║",
        f"║{' ' * (width - 2)}║",
        f"║{' ' * (width - 2)}║",
        f"║{' ' * name_padding}{full_name}{' ' * name_padding}║",
        f"║{' ' * (width - 2)}║",
        f"║{' ' * (width - 2)}║",
        f"║{' ' * (width - 2)}║",
        f"║ {suit_char}{' ' * (width - 7)}{card_type} ║",
        f"╚{'═' * (width - 2)}╝"
    ]

    return card_lines

def print_cards_side_by_side(cards):
    card_lines_list = [generate_card_lines(card) for card in cards]
    total_width = shutil.get_terminal_size().columns
    card_width = 20
    spacing_between_cards = 2
    total_cards_width = len(cards) * card_width + (len(cards) - 1) * spacing_between_cards

    left_padding = (total_width - total_cards_width) // 2

    for lines in zip(*card_lines_list):
        print(' ' * left_padding + "  ".join(lines))

def print_menu(title, items=[], prompt='', algo_items=[]):
    width = shutil.get_terminal_size().columns
    height = shutil.get_terminal_size().lines
    main_width = 46
    
    # Calculate main menu height
    main_height = 5 if len(items) <= 5 else len(items)
    
    # Only process algo box if algo_items is not empty
    show_algo_box = len(algo_items) > 0
    
    # Calculate algo box height and width
    algo_height = 5 if len(algo_items) <= 5 else len(algo_items)
    height_to_use = max(main_height, algo_height) if show_algo_box else main_height
    algo_width = 30  # Fixed width for algo box
    
    # Start drawing the UI
    move_cursor(29, 1)
    
    # Calculate the center position for the main menu
    main_menu_center = width // 2
    main_menu_left = main_menu_center - (main_width // 2) - 1
    
    # Calculate the position for the algo box (to the right of main menu)
    algo_box_left = main_menu_left + main_width + 2 + 5  # 5 spaces to the right of main menu
    
    # Custom function to print main menu centered and algo box to the right
    def print_menu_line(main_content, algo_content=None):
        spaces_before_main = main_menu_left
        print(" " * spaces_before_main + main_content, end="")
        
        if show_algo_box and algo_content:
            spaces_between = algo_box_left - (main_menu_left + len(strip_ansi(main_content)))
            print(" " * spaces_between + algo_content)
        else:
            print()
    
    # Top border with title
    if show_algo_box:
        
        print_menu_line(
            f"╔{'═' * main_width}╗", 
            f"╔{'═' * algo_width}╗"
        )
        clean_text = strip_ansi(algo_items[0])
        padding_left = (algo_width - len(clean_text)) // 2
        padding_right = (algo_width - len(clean_text) + 1) // 2
        print_menu_line(
            f"║{' ' * ((main_width - len(title)) // 2)}{title}{' ' * ((main_width - len(title) + 1) // 2)}║", 
            f"║{' ' * padding_left}{algo_items[0]}{' ' * padding_right}║"
        )
        print_menu_line(
            f"╠{'═' * main_width}╣", 
            f"╠{'═' * algo_width}╣"
        )
        del algo_items[0]
    else:
        print_centered(f"╔{'═' * main_width}╗")
        print_centered(f"║{' ' * ((main_width - len(title)) // 2)}{title}{' ' * ((main_width - len(title) + 1) // 2)}║")
        print_centered(f"╠{'═' * main_width}╣")
    
    # Draw the main content area
    for row in range(height_to_use):
        # Process main menu items
        main_item_str = ""
        if row < len(items) and items[row]:
            clean_text = strip_ansi(items[row])
            padding_left = (main_width - len(clean_text)) // 2
            padding_right = (main_width - len(clean_text) + 1) // 2
            main_item_str = f"║{' ' * padding_left}{items[row]}{' ' * padding_right}║"
        else:
            main_item_str = f"║{' ' * main_width}║"
            
        # Only process and display algo items if show_algo_box is True
        if show_algo_box:
            # Process algo items
            algo_item_str = ""
            if row < len(algo_items) and algo_items[row]:
                clean_text = strip_ansi(algo_items[row])
                padding_left = (algo_width - len(clean_text)) // 2
                padding_right = (algo_width - len(clean_text) + 1) // 2
                algo_item_str = f"║{' ' * padding_left}{algo_items[row]}{' ' * padding_right}║"
            else:
                algo_item_str = f"║{' ' * algo_width}║"
                
            # Print both sections
            print_menu_line(main_item_str, algo_item_str)
        else:
            # Only print main menu
            print_centered(main_item_str)
    
    # Bottom borders and prompt
    if show_algo_box:
        print_menu_line(
            f"╠{'═' * main_width}╣", 
            f"╚{'═' * algo_width}╝"
        )
    else:
        print_centered(f"╠{'═' * main_width}╣")
        
    print_centered(f"║{' ' * ((main_width - len(prompt)) // 2)}{prompt}{' ' * ((main_width - len(prompt) + 1) // 2)}║")
    print_centered(f"╚{'═' * main_width}╝")
    
    # Position cursor for input
    prompt_row = 33 + height_to_use if 33 + height_to_use < height - 2 else height - 2
    prompt_length = len(strip_ansi(prompt))  
    prompt_col = (width - prompt_length) // 2 + len(prompt) + 1
    move_cursor(prompt_row, prompt_col)

class Game:
    def __init__(self, num_decks, num_players, auto, auto_balance, auto_bet):
        self.num_decks = num_decks
        self.deck = [value + suit for suit in suits for value in values] * num_decks
        random.shuffle(self.deck)
        self.num_players = num_players
        self.auto = auto
        self.auto_bet = auto_bet
        self.played_cards = {value: 0 for value in values}
        if self.auto:
            self.players = [Player(player_num=num+1, balance=auto_balance) for num in range(num_players)]
        else:
            self.players = [Player(player_num=num+1) for num in range(num_players)]
        self.dealer = Dealer()
    
    def reset(self):
        for player in self.players:
            player.reset()
        self.dealer.reset()

    def deal_card(self):
        if not self.deck:
            return None  # No cards left to deal
        
        card = self.deck.pop()
        card_value = card[0]
        self.played_cards[card_value] += 1

        return card

    def initial_deal(self):
        # Standard Deal
        for _ in range(2):
            for player in self.players:
                player.add_card(self.deal_card())
            self.dealer.add_card(self.deal_card())

        # # Dealer's Ace Deal
        # for _ in range(2):
        #     for player in self.players:
        #         player.add_card(self.deal_card())
        # self.dealer.add_card('AH')
        # self.dealer.add_card(self.deal_card())

    def deck_reshuffle_check(self):
        if len(self.deck) < self.num_players * 6:
            self.deck = [value + suit for suit in suits for value in values] * self.num_decks
            random.shuffle(self.deck)

    def distribute_chips(self):
        for player in self.players:
            while True:
                try:
                    clear_screen()
                    print_menu('Welcome to Terminal Blackjack',['', f"Player {player.player_num}", "Fund your account:"])
                    acc_bal = input().strip()
                    try:
                        acc_bal = round(float(acc_bal), 2)
                    except ValueError:
                        raise ListError(['', 'Error', '', 'Type a valid number.'])
                    if acc_bal > 0:
                        player.set_balance(acc_bal)
                        break
                    else:
                        raise ListError(['', 'Error', '' 'Cannot set negative balance'])
                except ListError as e:
                    clear_screen()
                    print_menu('Welcome to Terminal Blackjack', e.messages, 'Press enter to continue ')
                    input()

    def collect_bets(self, automatic):
        if automatic:
            for player in self.players:
                player.place_bet(self.auto_bet)
        else:
            for player in self.players:
                while True:
                    try:
                        clear_screen()
                        print_menu('Place Your Bets',['', f"Player {player.player_num}", '', f"Balance: {format_amount(player.balance)}"], 'Bet: ')
                        bet = input().strip()
                        try:
                            bet = round(float(bet), 2)
                            player.place_bet(bet)
                            break
                        except ValueError as e:
                            raise ListError(['', 'Error', str(e), 'Type a valid number.'])
                    except ListError as e:
                        clear_screen()
                        print_menu('Place Your Bets', e.messages, 'Press enter to continue ')
                        input()

    def collect_insurance(self):
        for player in self.players:
            while True:
                try:
                    insurance_options = ['', f"Player {player.player_num}"]
                    if round(player.bet_value[0]/2, 2) < player.balance:
                        insurance_options.append(f"Insurance Bet: in range 0:{format_amount(player.bet_value[0]/2)}")
                    else:
                        insurance_options.append(f"Insurance bet: in range 0:{format_amount(player.balance)}")
                    
                    self.print_hands(player_index=player.player_num-1)
                    print_menu('Optional Insurance', insurance_options, 'Insurance Bet: ')

                    insurance = input().strip()
                    try:
                        insurance = round(float(insurance), 2)
                        player.place_insurance_bet(insurance)
                        break
                    except ValueError as e:
                        raise ListError(['', 'Error', str(e), 'Type a valid number.'])
                except ListError as e:
                    self.print_hands(player_index=player.player_num-1)
                    print_menu('Optional Insurance', e.messages, 'Press enter to continue ')
                    input()

    def print_hands(self, player_index, show_dealers_second_card=False, as_double_down=False):
        clear_screen()
        move_cursor(1, 1)

        # Dealer's hand
        print_centered('Dealer')
        if show_dealers_second_card:
            print_cards_side_by_side(self.dealer.card_list[0])
            print_centered(f'Total: {self.dealer.card_sum[0]}\n')
        else:
            print_cards_side_by_side(self.dealer.card_list[0][:-1] + ['  '])
            print_centered(f'Visible Total: {self.dealer.partial_sum(len(self.dealer.card_list[0]) - 1)}\n')
        
        if player_index < 0 or player_index >= self.num_players:
            raise ListError(['', 'Error in print_hands', '', f'Passed invalid player_index: {player_index}'])

        # Players' hands
        if self.players[player_index].num_hands > 1:
            print_centered(f'Player {player_index + 1} | Hand {self.players[player_index].current_hand_index+1} of {self.players[player_index].num_hands}')
        else:
            print_centered(f'Player {player_index + 1}')
        if as_double_down:
            print_cards_side_by_side(self.players[player_index].card_list[self.players[player_index].current_hand_index][:-1] + ['  '])
            print_centered(f'Visible Total: {self.players[player_index].partial_sum(len(self.players[player_index].card_list[self.players[player_index].current_hand_index]) - 1)}\
 | Bet: {format_amount(self.players[player_index].bet_value[self.players[player_index].current_hand_index])}')
        else:
            print_cards_side_by_side(self.players[player_index].card_list[self.players[player_index].current_hand_index])
            print_centered(f'Total: {self.players[player_index].card_sum[self.players[player_index].current_hand_index]} | Bet: {format_amount(self.players[player_index].bet_value[self.players[player_index].current_hand_index])}')

    def inspect_hands(self):
        while True:
            try:
                self.print_hands(player_index=0, show_dealers_second_card=True)
                print_menu('Inspect Hands', ['', 'Enter a player number to inspect', '', 'Zero to return'])

                if self.num_players > 1:
                    next_action = input().strip()
                else:
                    next_action = '1'

                if not next_action.isdigit():
                    next_action = 0
                    raise ListError(['', 'Error', '', "Input must be a numeric value."])
                
                next_action = int(next_action) - 1

                if next_action == -1:
                    break
                
                if next_action < 0 or next_action >= len(self.players):
                    next_action = 0
                    raise ListError(['', 'Error', '', "Player index is out of range."])
                
                # If no exceptions are raised, print the player's hands
                self.print_hands(player_index=next_action, show_dealers_second_card=True)
                items = []
                items.extend(str(self.players[next_action]).split(','))
                print_menu(f'Player {next_action+1}', items, 'Press enter to continue ')
                input()
            
                if self.num_players == 1:
                    break

            except ListError as e:
                self.print_hands(player_index=next_action, show_dealers_second_card=True)
                print_menu('Inspect Hands', e.messages, 'Press enter to continue ')
                input() # Press enter to continue

    def log_game(self):
        # Create the log folder if it doesn't exist
        log_folder = 'logs'
        if not os.path.exists(log_folder):
            os.mkdir(log_folder)

        # Build the game dictionary
        game_log = {
            "dealer": self.dealer.get_hand()["dealer_hand"],
            "players": []
        }

        for i in range(self.num_players):
            player_data = self.players[i].get_hand()
            player_entry = {"hands": player_data["hands"]}
            # Include insurance bet only if it exists
            if player_data["insurance_bet"] is not None:
                player_entry["insurance_bet"] = player_data["insurance_bet"]
            game_log["players"].append(player_entry)

        # Write to the JSON file (append or create)
        log_file = os.path.join(log_folder, 'game_history.json')
        if os.path.exists(log_file):
            with open(log_file, 'r+') as file:
                data = json.load(file)
                data.append(game_log)
                file.seek(0)
                json.dump(data, file, indent=2)
        else:
            with open(log_file, 'w') as file:
                json.dump([game_log], file, indent=2)


    def play_game(self):
        table_manager = LookupTableManager()
        continue_play = True
        if not self.auto:
            self.distribute_chips()
        while continue_play:
            clear_screen()
            self.collect_bets(automatic=self.auto)
            self.initial_deal()

            # Ace Card Check for Insurance
            insurance_active = self.dealer.check_ace_card()
            if insurance_active:
                self.print_hands(player_index=0)
                print_menu('Dealers Turn')
                time.sleep(0.8)
                self.print_hands(player_index=0)
                print_menu('Dealers Turn', ['','Dealer\'s ace card showing'])
                time.sleep(0.8)
                self.print_hands(player_index=0)
                print_menu('Dealers Turn', ['','Dealer\'s ace card showing','','Collecting optional Insurance bets'], 'Press enter to continue ')
                input()
                self.collect_insurance()

            # Blackjack Check
            dealer_blackjack = False
            if self.dealer.check_possible_blackjack():
                self.print_hands(player_index=0)
                print_menu('Dealers Turn')
                time.sleep(0.8)
                self.print_hands(player_index=0)
                print_menu('Dealers Turn', ['', 'Dealer checking for Blackjack'])
                time.sleep(0.8)
                
                if self.dealer.has_blackjack():
                    dealer_blackjack = True
                    self.print_hands(player_index=0, show_dealers_second_card=True)
                    for player in self.players:
                        if player.card_sum[0] == 21:
                            player.set_flag('is_push')
                    if insurance_active:
                        print_menu('Dealers Turn', ['', 'Dealer has Blackjack.'])
                        time.sleep(0.8)
                        self.print_hands(player_index=0, show_dealers_second_card=True)
                        print_menu('Dealers Turn', ['', 'Dealer has Blackjack.', 'Original bets lost.'])
                        time.sleep(0.8)
                        self.print_hands(player_index=0, show_dealers_second_card=True)
                        print_menu('Dealers Turn', ['', 'Dealer has Blackjack.', 'Original bets lost.', 'Optional Insurance won.'])
                        for player in self.players: player.win_insurance()
                        time.sleep(0.8)
                        self.print_hands(player_index=0, show_dealers_second_card=True)
                        print_menu('Dealers Turn', ['', 'Dealer has Blackjack.', 'Original bets lost.', 'Optional Insurance won.'], 'Press enter to continue ')
                    else: # normal blackjack sequence
                        self.print_hands(player_index=0, show_dealers_second_card=True)
                        print_menu('Dealers Turn', ['', 'Dealer has Blackjack.'])
                        time.sleep(0.8)
                        self.print_hands(player_index=0, show_dealers_second_card=True)
                        print_menu('Dealers Turn', ['', 'Dealer has Blackjack.', 'All players lose.'])
                        time.sleep(0.8)
                        self.print_hands(player_index=0, show_dealers_second_card=True)
                        print_menu('Dealers Turn', ['', 'Dealer has Blackjack.', 'All players lose.', 'Unless you ALSO have blackjack'])
                        time.sleep(0.8)
                        self.print_hands(player_index=0, show_dealers_second_card=True)
                        print_menu('Dealers Turn', ['', 'Dealer has Blackjack.', 'All players lose.'], 'Press enter to continue ')
                    input() # Press enter to continue

                else: # dealer does not have blackjack
                    if insurance_active:
                        self.print_hands(player_index=0)
                        print_menu('Dealers Turn', ['', 'Dealer does NOT have Blackjack.'])
                        time.sleep(0.8)
                        self.print_hands(player_index=0)
                        print_menu('Dealers Turn', ['', 'Dealer does NOT have Blackjack.', 'Optional insurance bets lost.'])
                    else: # normal lack of blackjack sequence
                        self.print_hands(player_index=0)
                        print_menu('Dealers Turn', ['', 'Dealer does NOT have Blackjack.'])
                    time.sleep(1)

            # Players' turns
            if not dealer_blackjack:
                for player in self.players:

                    # visualize player cards                    
                    while player.current_hand_index < player.num_hands:
                        
                        if player.card_sum[player.current_hand_index] == 21:
                            player.set_flag('is_blackjack')
                            self.print_hands(player_index=player.player_num-1)
                            print_menu(f'Player {player.player_num}\'s turn')
                            time.sleep(0.8)
                            self.print_hands(player_index=player.player_num-1)
                            print_menu(f'Player {player.player_num}\'s turn', ['', '', '* YOU GOT BLACKJACK *'])
                            time.sleep(1)
                            action = PlayerAction.STAND
                            
                        else: # no blackjack, play normally
                            available_actions=player.get_available_actions()
                            can_split = True if PlayerAction.SPLIT in available_actions else False
                            can_dd = True if PlayerAction.DOUBLE_DOWN in available_actions else False

                            self.print_hands(player_index=player.player_num-1)
                            print_menu(f'Player {player.player_num}\'s turn')
                            time.sleep(0.8)
                            self.print_hands(player_index=player.player_num-1)

                            action = None
                            while not action: # continually scan for player action
                                try:
                                    actions_list = ['0 : Stand      ', '1 : Hit        ']
                                    if can_split: actions_list.append('2 : Split      ')
                                    else: actions_list.append('')
                                    if can_dd: actions_list.append('3 : Double-Down')
                                    else: actions_list.append('')
                                    actions_list.append('4 : Surrender  ')

                                    rec = get_table_action(self.get_dealers_card(), player.card_sum[player.current_hand_index], 
                                                            player.get_reserve_aces(), player.get_available_actions(), explore=False)
                                    
                                    algo_items = []
                                    algo_items.append(f'Algo Says: \033[1m{rec.colored_name()}')

                                    full_action_dict = get_all_actions(self.get_dealers_card(), player.card_sum[player.current_hand_index], 
                                                                        player.get_reserve_aces(), player.get_available_actions())
                                    
                                    for act in full_action_dict:
                                        algo_items.append(f"{act} : {full_action_dict[act]:.2f}")

                                    self.print_hands(player_index=player.player_num-1)
                                    print_menu('Available Actions:', actions_list, 'Your Move: ', algo_items)

                                    user_input = input().strip().lower()
                                    action = PlayerAction.from_input(user_input, can_split=can_split, can_dd=can_dd)
                                except ValueError:
                                    self.print_hands(player_index=player.player_num-1)
                                    print_menu('Available Actions:', ['', 'Error', '', 'Action not available'], 'Enter a valid action... ')
                                    input()


                        if action == PlayerAction.DOUBLE_DOWN:
                            player.double_down_bet()
                            player.add_card(self.deal_card())
                            self.print_hands(player_index=player.player_num-1, as_double_down=True)
                            print_menu(f'Player {player.player_num}\'s turn')
                            time.sleep(0.8)
                            self.print_hands(player_index=player.player_num-1, as_double_down=True)
                            print_menu(f'Player {player.player_num}\'s turn', ['', '', 'You Doubled Down'])
                            time.sleep(1)
                            # skip further player querry
                            action = PlayerAction.STAND

                        while True:

                            if action == PlayerAction.STAND:
                                player.current_hand_index += 1
                                break

                            elif action == PlayerAction.HIT:
                                player.add_card(self.deal_card())
                                self.print_hands(player_index=player.player_num-1)
                                if player.is_bust():
                                    print_menu(f'Player {player.player_num}\'s turn', ['', '', 'Bust'])
                                    time.sleep(0.8)
                                    player.current_hand_index += 1
                                    break
                                elif player.card_sum[player.current_hand_index] == 21:
                                    print_menu(f'Player {player.player_num}\'s turn', ['', '', 'You got 21'])
                                    time.sleep(0.8)
                                    player.current_hand_index += 1
                                    break
                                else: # get new action
                                    action = None
                                    available_actions=player.get_available_actions()
                                    can_split = True if PlayerAction.SPLIT in available_actions else False
                                    can_dd = True if PlayerAction.DOUBLE_DOWN in available_actions else False

                                    while not action: # continually scan for player action
                                        try:
                                            actions_list = ['0 : Stand      ', '1 : Hit        ']
                                            if can_split: actions_list.append('2 : Split      ')
                                            else: actions_list.append('')
                                            if can_dd: actions_list.append('3 : Double-Down')
                                            else: actions_list.append('')
                                            actions_list.append('4 : Surrender  ')

                                            rec = get_table_action(self.get_dealers_card(), player.card_sum[player.current_hand_index], 
                                                                    player.get_reserve_aces(), player.get_available_actions(), explore=False)

                                            algo_items = []
                                            algo_items.append(f'Algo Says: \033[1m{rec.colored_name()}')

                                            full_action_dict = get_all_actions(self.get_dealers_card(), player.card_sum[player.current_hand_index], 
                                                                                player.get_reserve_aces(), player.get_available_actions())
                                            
                                            for act in full_action_dict:
                                                algo_items.append(f"{act} : {full_action_dict[act]:.2f}")

                                            self.print_hands(player_index=player.player_num-1)
                                            print_menu('Available Actions:', actions_list, 'Your Move: ', algo_items)

                                            user_input = input().strip().lower()
                                            action = PlayerAction.from_input(user_input, can_split=can_split, can_dd=can_dd)
                                        except ValueError:
                                            self.print_hands(player_index=player.player_num-1)
                                            print_menu('Available Actions:', ['', 'Error', '', 'Action not available'], 'Enter a valid action... ')
                                            input()

                            elif action == PlayerAction.SPLIT:
                                player.split_hand(self.deal_card(), self.deal_card())
                                self.print_hands(player_index=player.player_num-1)
                                print_menu(f'Player {player.player_num}\'s turn')
                                time.sleep(1)
                                self.print_hands(player_index=player.player_num-1)
                                print_menu(f'Player {player.player_num}\'s turn', ['', 'You split your pair.'])
                                time.sleep(1)
                                self.print_hands(player_index=player.player_num-1)
                                print_menu(f'Player {player.player_num}\'s turn', ['', 'You split your pair.', 'Dealing two additional cards.'])
                                time.sleep(1)
                                self.print_hands(player_index=player.player_num-1)
                                print_menu(f'Player {player.player_num}\'s turn', ['', 'You split your pair.', 'Dealing two additional cards.', 'Placing another bet for your second hand.'])
                                time.sleep(1)
                                self.print_hands(player_index=player.player_num-1)
                                print_menu(f'Player {player.player_num}\'s turn', ['', 'You split your pair.', 'Dealing two additional cards.', 'Placing another bet for your second hand.'], 'Press enter to continue ')
                                input() # Press enter to continue
                                # self.print_hands(player_index=player.player_num-1)
                                break

                            else: # elif action == PlayerAction.SURRENDER:
                                player.surrender()
                                self.print_hands(player_index=player.player_num-1)
                                print_menu(f'Player {player.player_num}\'s turn')
                                time.sleep(0.8)
                                self.print_hands(player_index=player.player_num-1)
                                print_menu(f'Player {player.player_num}\'s turn', ['', 'You surrendered.'])
                                time.sleep(0.8)
                                self.print_hands(player_index=player.player_num-1)
                                print_menu(f'Player {player.player_num}\'s turn', ['', 'You surrendered.', 'Half your bet is returned.'])
                                time.sleep(0.8)
                                self.print_hands(player_index=player.player_num-1)
                                print_menu(f'Player {player.player_num}\'s turn', ['', 'You surrendered.', 'Half your bet is returned.'], 'Press enter to continue ')
                                player.current_hand_index+=1
                                input() # Press enter to continue
                                break
                    
                    # back to first hand after all hands are played
                    player.current_hand_index = 0

            # Dealer's turn

            # visualize player cards (reveal dealer's second card)
            self.print_hands(player_index=0, show_dealers_second_card=True)
            print_menu('Dealers Turn')

            while self.dealer.should_hit():
                time.sleep(0.8)
                self.dealer.add_card(self.deal_card())
                self.print_hands(player_index=0, show_dealers_second_card=True)
                print_menu('Dealers Turn')

            # Determine results and award winnings
            dealer_sum = self.dealer.card_sum[0]

            # list of results
            results = []

            for player in self.players:
                player.current_hand_index = 0
                if player.num_hands == 1:
                    if player.get_flag('is_blackjack') and not dealer_blackjack:
                        player.win_blackjack()
                        results.append(f'Player {player.player_num}: BLACKJACK | {player.card_sum[0]} | {self.dealer.card_sum[0]} |')
                    elif player.get_flag('is_surrendered'):
                        # bet already managed during turn
                        results.append(f"Player {player.player_num}: SURRENDER | {player.card_sum[0]} | {self.dealer.card_sum[0]} |")
                    elif player.is_bust():
                        player.loss()
                        results.append(f'Player {player.player_num}: YOU LOSE  | {player.card_sum[0]} | {self.dealer.card_sum[0]} |')
                    elif self.dealer.is_bust() or player.card_sum[0] > dealer_sum :
                        player.win()
                        results.append(f'Player {player.player_num}: YOU WIN   | {player.card_sum[0]} | {self.dealer.card_sum[0]} |')
                    elif player.card_sum[0] < dealer_sum:
                        player.loss()
                        results.append(f'Player {player.player_num}: YOU LOSE  | {player.card_sum[0]} | {self.dealer.card_sum[0]} |')
                    else:
                        player.push()
                        results.append(f"Player {player.player_num}: PUSH      | {player.card_sum[0]} | {self.dealer.card_sum[0]} |")

                else: # a split has occurred
                    results.append(f"Player {player.player_num}: SPLIT DECK RESULTS:  ")
                    while player.current_hand_index < player.num_hands:
                        if player.get_flag('is_blackjack') and not dealer_blackjack:
                            player.win_blackjack()
                            results.append(f'    Hand {player.current_hand_index+1}: BLACKJACK | {player.card_sum[player.current_hand_index]} | {self.dealer.card_sum[0]} |')
                        elif player.get_flag('is_surrendered'):
                            # bet already managed during turn
                            results.append(f"    Hand {player.current_hand_index+1}: SURRENDER | {player.card_sum[player.current_hand_index]} | {self.dealer.card_sum[0]} |")
                        elif player.is_bust():
                            player.loss()
                            results.append(f'    Hand {player.current_hand_index+1}: YOU LOSE  | {player.card_sum[player.current_hand_index]} | {self.dealer.card_sum[0]} |')
                        elif self.dealer.is_bust() or player.card_sum[player.current_hand_index] > dealer_sum:
                            player.win()
                            results.append(f'    Hand {player.current_hand_index+1}: YOU WIN   | {player.card_sum[player.current_hand_index]} | {self.dealer.card_sum[0]} |')
                        elif player.card_sum[player.current_hand_index] < dealer_sum:
                            player.loss()
                            results.append(f'    Hand {player.current_hand_index+1}: YOU LOSE  | {player.card_sum[player.current_hand_index]} | {self.dealer.card_sum[0]} |')
                        else:
                            player.push()
                            results.append(f"    Hand {player.current_hand_index+1}: PUSH      | {player.card_sum[player.current_hand_index]} | {self.dealer.card_sum[0]} |")
                        player.current_hand_index += 1
                    player.current_hand_index = 0

                if insurance_active and player.insurance_bet != 0:
                    if not dealer_blackjack:
                        # bet already managed during turn
                        results.append("        INSURANCE | Lost side pot")
                    else:
                        results.append("        INSURANCE | Won side pot at 2x")

            # log results before reset questionaire
            self.log_game()

            while True:

                self.print_hands(player_index=0, show_dealers_second_card=True)
                print_menu('Round Results', results, 'Play again? [i for inspect hands]  ')

                user_input = input().strip().lower()
                if user_input == 'i':
                    self.inspect_hands()
                elif user_input in ['1', 'y']:
                    continue_play = True
                    break
                elif user_input in ['0', 'n']:
                    continue_play = False
                    break
                else:
                    continue

            self.deck_reshuffle_check()
            self.reset()

        clear_screen()

    def get_dealers_card(self):
        card = self.dealer.card_list[0][0][0] # dealers card value
        return 'X' if card in ['J', 'Q', 'K'] else card


if __name__ == '__main__':
    while True:
        try:
            clear_screen()
            print_menu('Welcome to Terminal Blackjack', ['', 'Thomas O\'Connor 2025', '', 'How many players [1:4]?'])
            user_input = input().strip()

            inputs = user_input.split()
            if len(inputs)==0 or not inputs[0].isdigit():
                raise ListError(["", "Incorrect format.", "", "Number of players must be between 1 and 4."])
            num_players = int(inputs[0])

            # Check if num_players is within the valid range
            if num_players < 1 or num_players > 4:
                raise ListError(["", "Incorrect format.", "", "Number of players must be between 1 and 4."])

            if len(inputs) == 1:
                auto_mode = False
                balance_val = None
                bet_val = None
                break
            elif len(inputs) == 3:
                auto_mode = True
                balance_val = round(float(inputs[1]), 2)
                bet_val = round(float(inputs[2]), 2)
                break
            else:
                raise ListError(["Incorrect format.", "Please use the following syntax:", "[ num_players ]",  "or", "[ num_players, balance_val, bet_val ]"])
        except ListError as e:
            clear_screen()
            print_menu('Welcome to Terminal Blackjack', e.messages, 'Press enter to continue ')
            input()
    clear_screen()
    game = Game(num_decks=6, num_players=num_players, auto=auto_mode, auto_balance=balance_val, auto_bet=bet_val)
    game.play_game()
