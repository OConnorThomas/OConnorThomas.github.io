import random
import os
import time
import json
import sys
from tqdm import tqdm

from players import Player, Dealer, PlayerAction
from algo import get_table_action, update_table, LookupTableManager

values = ('A', '2', '3', '4', '5', '6', '7', '8', '9', 'X', 'J', 'Q', 'K')
suits = ('H', 'D', 'S', 'C')
    
def get_fresh_deck(num_decks):
    return [value + suit for suit in suits for value in values] * num_decks

class Game:
    def __init__(self, num_decks):
        self.num_decks = num_decks
        self.deck = get_fresh_deck(self.num_decks)
        random.shuffle(self.deck)
        self.player = Player(player_num=1)
        self.dealer = Dealer()
    
    def reset(self):
        self.player.reset()
        self.dealer.reset()

    def deal_card(self):
        # auto reshuffle
        if not self.deck:
            self.deck = get_fresh_deck(self.num_decks)
            random.shuffle(self.deck)

        return self.deck.pop()

    def initial_deal(self):
        # Standard Deal
        for _ in range(2):
            self.player.add_card(self.deal_card())
            self.dealer.add_card(self.deal_card())

    def play_game(self, num_games):
        table_manager = LookupTableManager()
        for game in tqdm(range(int(num_games)), desc='Training Table Lookup Model', ncols=120, unit=" games", colour="#A74B08"):
            self.initial_deal()

            # Players' turns
            if not self.dealer.has_blackjack():
          
                while self.player.current_hand_index < self.player.num_hands:
                    
                    if self.player.card_sum[self.player.current_hand_index] == 21:
                        action = PlayerAction.STAND
                        
                    else: # no blackjack, play normally
                        # select action programmatically
                        old_card_sum = self.player.card_sum[self.player.current_hand_index]
                        reserve_aces = self.player.get_reserve_aces()

                        action = get_table_action(self.get_dealers_first_card(), 
                                old_card_sum, reserve_aces, self.player.get_available_actions(),
                                game_num=game, explore=True)

                        self.player.states[self.player.current_hand_index][0] = (old_card_sum, reserve_aces, action)

                    while True:

                        if action == PlayerAction.DOUBLE_DOWN:
                            self.player.add_card(self.deal_card())
                            action = PlayerAction.STAND

                        if action == PlayerAction.STAND:
                            self.player.current_hand_index += 1
                            break

                        elif action == PlayerAction.HIT:
                            self.player.add_card(self.deal_card())
                            if self.player.is_bust() or self.player.card_sum[self.player.current_hand_index] == 21:
                                self.player.current_hand_index += 1
                                break
                            else: # get new action
                                update_table(self.get_dealers_first_card(), old_card_sum, reserve_aces, action, 'is_under')
                            
                                # select action programmatically
                                old_card_sum = self.player.card_sum[self.player.current_hand_index]
                                reserve_aces = self.player.get_reserve_aces()

                                action = get_table_action(self.get_dealers_first_card(), 
                                        old_card_sum, reserve_aces, self.player.get_available_actions(),
                                        game_num=game, explore=True)
                                
                                self.player.states[self.player.current_hand_index].append((old_card_sum, reserve_aces, action))

                        elif action == PlayerAction.SPLIT:
                            self.player.split_hand(self.deal_card(), self.deal_card())
                            # don't update table: split treated as new hands
                            break
                    
                    # back up to while self.player.current_hand_index < self.player.num_hands:
                
                # back to first hand after all hands are played
                self.player.current_hand_index = 0

            # Dealer's turn

            while self.dealer.should_hit():
                self.dealer.add_card(self.deal_card())

            # Determine results and award winnings
            dealer_sum = self.dealer.card_sum[0]

            self.player.current_hand_index = 0
            while self.player.current_hand_index < self.player.num_hands:
                for state in self.player.states[self.player.current_hand_index]:
                    if state: # if action taken, unpack and update
                        card_sum, reserve_aces, action = state

                        if self.player.is_bust():
                            update_table(self.get_dealers_first_card(), card_sum, reserve_aces, action, 'is_lost')
                        elif self.dealer.is_bust():
                            update_table(self.get_dealers_first_card(), card_sum, reserve_aces, action, 'is_won')
                        elif self.player.card_sum[self.player.current_hand_index] > dealer_sum:
                            update_table(self.get_dealers_first_card(), card_sum, reserve_aces, action, 'is_won')
                        elif self.player.card_sum[self.player.current_hand_index] < dealer_sum:
                            update_table(self.get_dealers_first_card(), card_sum, reserve_aces, action, 'is_lost')
                        else:
                            pass

                        # is_21 flag on top of any final results, achieved outside of blackjack
                        if self.player.card_sum[self.player.current_hand_index] == 21:
                            update_table(self.get_dealers_first_card(), card_sum, reserve_aces, action, 'is_21')
                    
                self.player.current_hand_index += 1
            self.player.current_hand_index = 0
            
            self.reset()

            # Save every 10% through testing
            if game % polling_rate == 0:
                table_manager.save_table()

        # Final save after all games
        table_manager.save_table()

    ##########################################
    # external methods for algorithm #
    ##########################################

    def get_dealers_first_card(self):
        """Static per-round"""
        card = self.dealer.card_list[0][0][0] # dealers card value
        return 'X' if card in ['J', 'Q', 'K'] else card


if __name__ == '__main__':
    game = Game(num_decks=6)
    if len(sys.argv) > 1:
        num_games = int(sys.argv[1])
    else:
        num_games = 10

    # arg as millions of games to simulate
    num_games *= 10e5

    polling_rate = int(num_games)/10
    
    game.play_game(num_games)

    from analyze_model import analyze
    analyze()