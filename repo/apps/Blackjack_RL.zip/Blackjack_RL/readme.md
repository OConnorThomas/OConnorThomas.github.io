# Blackjack Table Lookup Model

train.py : train the model with 10 million games.
Argv1 number of training games in millions

players.py : basic player, dealer functionality
contains PlayerAction enum

algo.py : Lookup Table
Singleton to conserve memory
get_table_action, update_table methods
manual query for live game reference

analyze_model.py : Visualize lookup table, algo params

main_visual.py : link algorithm to front-end game to visualize algorithm results
Includes players_betting.py to restore betting functionality (stripped from training model to increase efficiency)
PlayerAction enum retained from players.py for compatibility with algorithm
