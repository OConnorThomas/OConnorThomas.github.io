from algo import get_exploration_rate, explore_coeff_start, explore_coeff_min, decay_rate
import matplotlib.pyplot as plt
import os

def anneal_fig():
    num_games = int(10e6)
    found_convergence = False
    convergence_x = None

    y = []
    for i in range(num_games):
        y.append(get_exploration_rate(i))
        if not found_convergence and (y[-1] == explore_coeff_min):
            convergence_x = i
            found_convergence = True


    plt.plot([i for i in range(num_games)], y, color='orange')
    plt.title(f'Annealing Rate: start: {explore_coeff_start}, min: {explore_coeff_min}, deacy: {decay_rate}')
    plt.ylabel('Exploration percentage')
    plt.yticks([0.20, 0.175, 0.15, 0.125, 0.10, 0.075, 0.05, 0.025, explore_coeff_min])
    plt.ylim(0, explore_coeff_start)
    plt.axhline(explore_coeff_min, color='red', linestyle='--')
    plt.xlabel('Games as t->T')
    plt.xlim(0, num_games)
    plt.grid(True)

    plt.plot(convergence_x, explore_coeff_min, label=f'Convergence Point:\nGame: {convergence_x:,}', marker='o', linestyle='none', color='blue')
    plt.legend(loc='upper right')

    parent_dir = 'plots'
    if not os.path.exists(parent_dir):
        os.mkdir(parent_dir)
    plt.savefig(os.path.join(parent_dir, 'annealing_rate'))

import os
import json
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Polygon

from algo import MODEL_PATH, TABLE_FILE
from players import PlayerAction

# === File Constants ===
dealer_values = ['2', '3', '4', '5', '6', '7', '8', '9', 'X', 'A']
actions = ['n', 'h', 'd']
all_actions = [char.value for char in PlayerAction]
action_colors = {'n': 'blue', 'h': 'green', 's': 'purple', 'd': 'orange', 'c': 'red'}

# Load the lookup table
with open(TABLE_FILE, 'r') as f:
    table = json.load(f)

# Plotting
def plot_num_aces(num_aces: int):
    fig, axes = plt.subplots(5, 2, figsize=(50, 25), constrained_layout=True)
    fig.suptitle(f"Blackjack Lookup Table discovered optimal PlayerActions (Aces: {num_aces})", fontsize=30)

    for idx, dealer_card in enumerate(dealer_values):
        ax = axes[idx // 2, idx % 2]

        x = np.arange(4, 21)
        width = 0.25

        # Plot each action's total outcomes per player total
        for i, action in enumerate(actions):
            total_counts = []
            for total in range(4, 21):
                data = table[dealer_card][str(total)][f'{num_aces}']  # zero aces
                total_count = sum(data[action].values())
                total_counts.append(total_count)

            ax.bar(x + i * width, total_counts, width=width, label=action, color=action_colors[action], alpha=0.8)

        # Graph formatting
        ax.set_title(f"Dealer Card: {dealer_card}", fontsize=16)
        ax.set_xlabel("Player Hand Value", fontsize=14)
        ax.set_ylabel("Count", fontsize=14)
        ax.set_xticks(x + width * 1.5)
        ax.set_xticklabels(x)
        ax.grid(axis='y', linestyle='--', alpha=0.7)

    # Simplified legend for actions only
    fig.legend([plt.Rectangle((0, 0), 1, 1, color=action_colors[a]) for a in actions],
              [PlayerAction(action) for action in actions], loc='upper left', fontsize=22)

    parent_dir = 'plots'
    if not os.path.exists(parent_dir):
        os.mkdir(parent_dir)
    plt.savefig(os.path.join(parent_dir, f'{num_aces}a.png'))

# === Compute Best Actions per State ===
import numpy as np

def compute_best_action(num_aces):
    best_action_table = {}

    for dealer_card in dealer_values:
        best_action_table[dealer_card] = {}
        for total in range(4, 21):
            action_win_pct_list = []

            for action in actions:
                data = table[dealer_card][str(total)][str(num_aces)]

                # Extract win/loss counts
                win_count = data[action].get('is_won', 0) + (data[action].get('is_21', 0) * 0.5) + (data[action].get('is_under', 0) * 0.3)
                loss_count = data[action].get('is_lost', 0)
                total_count = win_count + loss_count

                # Compute win percentage or handle zero total_count
                win_pct = (win_count / total_count) if total_count > 0 else -np.inf

                # Log each action and its win percentage
                action_win_pct_list.append((action, win_pct))

            # Sort actions by win percentage in descending order
            action_win_pct_list.sort(key=lambda x: x[1], reverse=True)

            # Select the best action based on the highest win percentage
            best_action, best_win_pct = action_win_pct_list[0]

            best_action_table[dealer_card][str(total)] = (best_action, best_win_pct)

    return best_action_table


# === Save Best Action Tables ===
output_dir = 'best_action_tables'
os.makedirs(output_dir, exist_ok=True)
for num_aces in range(2):
    best_action_table = compute_best_action(num_aces)
    with open(os.path.join(output_dir, f'best_action_table_{num_aces}a.json'), 'w') as f:
        json.dump(best_action_table, f, indent=2)

def visualize_1x2_best_action_tables():
    fig, axs = plt.subplots(1, 2, figsize=(25, 10))
    unique_actions = sorted(set(all_actions))
    action_to_index = {action: i + 1 for i, action in enumerate(unique_actions)}  # Shift by 1 for lightgray at 0

    # Create a color map and normalization
    color_list = ['lightgray'] + [action_colors[action] for action in unique_actions]
    cmap = ListedColormap(color_list)
    norm = BoundaryNorm(boundaries=np.arange(len(color_list) + 1) - 0.5, ncolors=len(color_list))

    for idx, num_aces in enumerate(range(2)):
        ax = axs[idx]
        with open(os.path.join(output_dir, f'best_action_table_{num_aces}a.json'), 'r') as f:
            best_action_table = json.load(f)

        data_matrix = np.zeros((len(dealer_values), 17))
        for i, dealer_card in enumerate(dealer_values):
            for j, total in enumerate(range(4, 21)):
                if num_aces > 0 and total <= 11:
                    data_matrix[i, j] = 0  # Light gray for unachievable scenarios
                    win_pct = np.inf
                elif num_aces > 0 and total == 12:
                    data_matrix[i, j] = 5  # Hard code splits for dual aces
                    win_pct = 1.0
                elif num_aces == 0 and total == 4 and dealer_card in ['2', '3', '4', '5', '6', '7']:
                    data_matrix[i, j] = 5  # Hard code splits for twos at low dealer values
                    win_pct = 1.0
                else:
                    action, win_pct = best_action_table[dealer_card][str(total)]
                    data_matrix[i, j] = action_to_index[action]

                # If win_pct < 0.5, add a triangle to the top-right corner
                if win_pct < 0.5:
                    # Create triangle coordinates for top-right corner (j, i is the center of the cell)
                    triangle_x = [j + 0.5, j + 0.5, j - 0.5]  # right edge, right edge, center
                    triangle_y = [i - 0.5, i + 0.5, i - 0.5]  # top, bottom, top
                    
                    # Add the triangle using the color at index 1
                    from matplotlib.patches import Polygon
                    triangle = Polygon(np.column_stack([triangle_x, triangle_y]), 
                                     facecolor='red',
                                     alpha=1.0)
                    ax.add_patch(triangle)

                # Add text for win percentage
                ax.text(j, i, f'{win_pct:.2f}', ha='center', va='center', color='black')

        ax.imshow(data_matrix, cmap=cmap, norm=norm)

        ax.set_xticks(np.arange(17))
        ax.set_xticklabels(range(4, 21))
        ax.set_yticks(np.arange(len(dealer_values)))
        ax.set_yticklabels(dealer_values)
        ax.set_xlabel('Player Hand Value', fontsize=14)
        ax.set_ylabel('Dealer Card', fontsize=14)
        ax.set_title(f'Reserve Aces: {num_aces}', fontsize=16)
        ax.set_xticks(np.arange(-0.5, 17, 1), minor=True)
        ax.set_yticks(np.arange(-0.5, len(dealer_values), 1), minor=True)
        ax.grid(which='minor', color='black', linestyle='-', linewidth=1)
        ax.tick_params(which='minor', size=0)

    # Create a legend manually
    legend_elements = [plt.Line2D([0], [0], marker='s', color='w', label='Unachievable',
                                 markerfacecolor='lightgray', markersize=15)]
    for action, color in action_colors.items():
        legend_elements.append(plt.Line2D([0], [0], marker='s', color='w', label=f'Action: {str(PlayerAction(action)).split(".")[1]}',
                                        markerfacecolor=color, markersize=15))

    fig.legend(handles=legend_elements, loc='lower center', ncol=len(legend_elements), fontsize=14)

    plt.suptitle(f'Optimal Action Heatmaps for Aces [0–1]', fontsize=20)
    plt.subplots_adjust(top=0.90, bottom=0.15, wspace=0.3)
    plt.tight_layout(rect=[0, 0.1, 1, 0.95])

    plot_dir = 'plots'
    os.makedirs(plot_dir, exist_ok=True)
    plt.savefig(os.path.join(plot_dir, 'optimal_action_heatmaps.png'), dpi=300)
    plt.close()

def analyze():
    anneal_fig()
    for i in range(2):
        plot_num_aces(i)
    visualize_1x2_best_action_tables()


if __name__ == '__main__':
    analyze()