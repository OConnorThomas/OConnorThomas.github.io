# Monte Carlo Stock Market Simulator

## Author

Thomas O'Connor
Adaptation of Machine Learning Coursework
Spring 2024 \* Python3

## Contents

Trend_Sim.py : programmatic
Interactive_Trend_Sim.py : interactive

## Description

Leverages the following principles:
Drift
Volatility
Geometric Brownian Motion formula (normal distribution)

## Acknowledgements

Yahoo Finance
NumPy
MatPlotLib
TQDM
Professor Chris Geggis : UMass Lowell
