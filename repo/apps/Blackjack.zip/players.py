from enum import Enum

def format_amount(amount):
    if amount.is_integer():
        return int(amount)
    else:
        return amount

class PlayerAction(Enum):
    STAND = 'n'
    HIT = 'h'
    SPLIT = 's'
    DOUBLE_DOWN = 'd'
    SURRENDER = 'c'

    @classmethod
    def from_input(cls, input_value, can_split, can_dd):
        if input_value in ['0', 'n', 'stand']:
            return cls.STAND
        elif input_value in ['1', 'h', 'y', 'hit']:
            return cls.HIT
        elif input_value in ['2', 's', 'split'] and can_split:
            return cls.SPLIT
        elif input_value in ['3', 'd', 'dd', 'double down', 'double-down'] and can_dd:
            return cls.DOUBLE_DOWN
        elif input_value in ['4', 'c', 'cancel', 'forfeit', 'surrender']:
            return cls.SURRENDER
        else:
            raise ValueError("Invalid input")

class Player:
    def __init__(self, player_num=0, balance=0, is_dealer=False):
        self.player_num = player_num
        self.balance = balance
        self.bet_value = [0]

        self.card_list = [[]]
        self.card_sum = [0]
        self.current_hand_index = 0
        self.num_hands = 1

        # Hand-specific attribute flags
        self.hand_flags = [{
            'is_blackjack': False,
            'is_surrendered': False,
            'is_won': False,
            'is_lost': False,
            'is_push': False
        }]
        self.is_dealer = is_dealer

    def reset(self):
        self.bet_value = [0]
        self.card_list = [[]]
        self.card_sum = [0]
        self.current_hand_index = 0
        self.num_hands = 1
        self.hand_flags = [{
            'is_blackjack': False,
            'is_surrendered': False,
            'is_won': False,
            'is_lost': False,
            'is_push': False
        }]

    def set_balance(self, account_balance):
        self.balance = account_balance

    def place_bet(self, amount):
        amount = round(amount, 2)
        if amount > self.balance:
            raise ValueError("Insufficient balance")
        if amount < 0:
            raise ValueError("Cannot request negative balance")
        self.bet_value[self.current_hand_index] = amount
        self.balance -= amount

    def add_card(self, card):
        self.card_list[self.current_hand_index].append(card)
        self.update_card_sum()

    def update_card_sum(self):
        for i in range(0, self.num_hands):
            self.card_sum[i] = self.calculate_sum(self.card_list[i])

    def calculate_sum(self, cards):
        value_map = {
            'A': 11, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'X': 10,
            'J': 10, 'Q': 10, 'K': 10
        }
        total = 0
        aces = 0

        for card in cards:
            value = card[:-1]
            total += value_map[value]
            if value == 'A':
                aces += 1

        # Adjust for Aces
        while total > 21 and aces:
            total -= 10
            aces -= 1

        return total
    
    def partial_sum(self, num_cards):
        if num_cards > len(self.card_list[self.current_hand_index]):
            raise ValueError("num_cards is greater than the number of cards in hand.")
        return self.calculate_sum(self.card_list[self.current_hand_index][:num_cards])

    def is_bust(self):
        return self.card_sum[self.current_hand_index] > 21
    
    def split_hand(self, dealt_card_one, dealt_card_two):
        # take the existing set of cards
        existing_hand = self.card_list[self.current_hand_index]
        del self.card_list[self.current_hand_index]

        # divide them and splice them with provided cards from dealer
        self.card_list.append([existing_hand[0], dealt_card_one])
        self.card_list.append([existing_hand[1], dealt_card_two])

        # update new hand
        self.num_hands += 1
        self.bet_value.append(self.bet_value[self.current_hand_index])
        self.balance -= self.bet_value[self.current_hand_index]
        self.card_sum.append(0)
        self.update_card_sum()

        self.hand_flags.append({
            'is_blackjack': False,
            'is_surrendered': False,
            'is_won': False,
            'is_lost': False,
            'is_push': False
        })

    def set_flag(self, flag, value):
        self.hand_flags[self.current_hand_index][flag] = value

    def get_flag(self, flag):
        return self.hand_flags[self.current_hand_index][flag]
    
    def can_split(self):
        return self.card_list[self.current_hand_index][0][0] == self.card_list[self.current_hand_index][1][0] and len(self.card_list[self.current_hand_index]) == 2 and self.balance >= self.bet_value[self.current_hand_index]
    
    def can_dd(self):
        return self.balance >= self.bet_value[self.current_hand_index] and len(self.card_list[self.current_hand_index]) == 2

    def get_available_actions(self):
        base_actions = [PlayerAction.STAND, PlayerAction.HIT, PlayerAction.SURRENDER]
        if self.can_split(): 
            base_actions += [PlayerAction.SPLIT]
        if self.can_dd():
            base_actions += [PlayerAction.DOUBLE_DOWN]
        return base_actions
    
    def double_down_bet(self):
        self.balance -= self.bet_value[self.current_hand_index]
        self.bet_value[self.current_hand_index] += self.bet_value[self.current_hand_index]
    
    def win_blackjack(self):
        self.balance += round(self.bet_value[self.current_hand_index] * 2.5, 2)

    def win(self):
        self.balance += round(self.bet_value[self.current_hand_index] * 2, 2)
        self.set_flag('is_won', True)

    def loss(self):
        self.set_flag('is_lost', True)

    def push(self):
        self.balance += self.bet_value[self.current_hand_index]
        self.set_flag('is_push', True)

    def surrender(self):
        self.bet_value[self.current_hand_index] = round(self.bet_value[self.current_hand_index] / 2, 2)
        self.balance += self.bet_value[self.current_hand_index]
        self.set_flag('is_surrendered', True)

    def clear_bet(self):
        self.bet_value[self.current_hand_index] = 0

    def get_outcome(self):
        if self.get_flag('is_blackjack'):
            return "Blackjack"
        elif self.get_flag('is_surrendered'):
            return "Surrendered"
        elif self.get_flag('is_won'):
            return "Won"
        elif self.get_flag('is_lost'):
            return "Lost"
        elif self.get_flag('is_push'):
            return "Push"
        else:
            return "No outcome determined"


    def __str__(self):
        signs = {
            "Blackjack": '+',
            "Surrendered": '-',
            "Won": '+',
            "Lost": '-',
            "Push": ' '
        }

        role = " Dealer" if self.is_dealer else " Player"
        num = '' if self.is_dealer else self.player_num

        result = f"{role} {num}\n{'-' * 10}\n"

        self.current_hand_index = 0
        
        win_coef = 1.5 if self.get_flag('is_blackjack') else 1
        
        if self.num_hands > 1:
            while self.current_hand_index < self.num_hands:
                result += (
                    f"  Hand {self.current_hand_index + 1}\n"
                    f"  {'-' * 12}\n"
                    f"  Bet Value: {format_amount(self.bet_value[self.current_hand_index])}\n"
                    f"  Outcome:   {self.get_outcome()}\n"
                    f"            {signs[self.get_outcome()]}{format_amount(self.bet_value[self.current_hand_index] * win_coef)}\n\n"
                    f"  Card List: {', '.join(self.card_list[self.current_hand_index])}\n"
                    f"  Card Sum:  {self.card_sum[self.current_hand_index]}\n"
                    f"  {'-' * 12}\n"
                )
                self.current_hand_index += 1
            self.current_hand_index = 0
        else:
            result += (
                f"  Bet Value: {format_amount(self.bet_value[self.current_hand_index])}\n"
                f"  Outcome:   {self.get_outcome()}\n"
                f"            {signs[self.get_outcome()]}{format_amount(self.bet_value[self.current_hand_index] * win_coef)}\n\n"
                f"  Card List: {', '.join(self.card_list[self.current_hand_index])}\n"
                f"  Card Sum:  {self.card_sum[self.current_hand_index]}\n"
                f"{'-' * 10}\n"
            )

        result += f"  Balance:   {format_amount(self.balance)}\n"
        return result



class Dealer(Player):
    def __init__(self):
        super().__init__(is_dealer=True)


    def should_hit(self):
        return self.card_sum[0] < 17

    def check_possible_blackjack(self):
        return self.card_list[0][0][0] in ['A', 'X', 'J', 'Q', 'K']
        
    def has_blackjack(self):
        return (self.calculate_sum(self.card_list[0]) == 21) and (len(self.card_list[0]) == 2)
