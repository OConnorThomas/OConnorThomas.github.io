import random
import shutil  # terminal centering
import os
import time
from enum import Enum

from players import Player, Dealer, PlayerAction

values = ('A', '2', '3', '4', '5', '6', '7', '8', '9', 'X', 'J', 'Q', 'K')
suits = ('H', 'D', 'S', 'C')

def clear_screen():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')

def format_amount(amount):
    if amount.is_integer():
        return int(amount)
    else:
        return amount

def print_centered(text, width=None):
    if width is None:
        width = shutil.get_terminal_size().columns
    print(text.center(width))

def generate_card_lines(card_type):
    card_names = {
        'A': 'Ace',
        '2': 'Two',
        '3': 'Three',
        '4': 'Four',
        '5': 'Five',
        '6': 'Six',
        '7': 'Seven',
        '8': 'Eight',
        '9': 'Nine',
        'X': 'Ten',
        'J': 'Jack',
        'Q': 'Queen',
        'K': 'King',
        ' ': ''
    }
    
    suits = {
        'S': 'Spades',
        'H': 'Hearts',
        'D': 'Diamonds',
        'C': 'Clubs',
        ' ': ''
    }

    suit_char_refs = {
        'S': '♠',
        'H': '♥',
        'D': '♦',
        'C': '♣',
        ' ': ' '
    }
    
    value = card_type[:-1]  # Get all characters except the last one
    suit = card_type[-1]  # Get the last character

    full_name = f"{card_names.get(value, value)} of {suits.get(suit, '')}" if value != ' ' else ''
    width = 20  # Total width of the card including borders
    name_padding = (width - 2 - len(full_name)) // 2  # Calculate padding for centering the name

    if (width - 2 - len(full_name)) % 2 != 0:
        full_name = full_name + ' '

    suit_char = suit_char_refs.get(suit, '')

    card_lines = [
        f"*{'=' * (width - 2)}*",
        f"| {card_type}{' ' * (width - 7)}{suit_char} |",
        f"|{' ' * (width - 2)}|",
        f"|{' ' * (width - 2)}|",
        f"|{' ' * name_padding}{full_name}{' ' * name_padding}|",
        f"|{' ' * (width - 2)}|",
        f"|{' ' * (width - 2)}|",
        f"|{' ' * (width - 2)}|",
        f"| {suit_char}{' ' * (width - 7)}{card_type} |",
        f"*{'=' * (width - 2)}*"
    ]

    return card_lines

def print_cards_side_by_side(cards):
    card_lines_list = [generate_card_lines(card) for card in cards]
    total_width = shutil.get_terminal_size().columns
    card_width = 22
    spacing_between_cards = 2
    total_cards_width = len(cards) * card_width + (len(cards) - 1) * spacing_between_cards

    left_padding = (total_width - total_cards_width) // 2

    for lines in zip(*card_lines_list):
        print(' ' * left_padding + "  ".join(lines))

def get_player_action(available_actions):
    while True:
        try:
            can_split = False
            can_dd = False
            # unpack list for flags
            if PlayerAction.SPLIT in available_actions: can_split = True
            if PlayerAction.DOUBLE_DOWN in available_actions: can_dd = True

            # based on flags, request appropriate response
            if can_split and can_dd:
                action = input("Available actions:\n0 | 'n': Stand\n1 | 'h': Hit\n2 | 's': Split\n3 | 'd': Double-Down\n4 | 'c': Surrender\n").strip().lower()
            elif not can_split and can_dd:
                action = input("Available actions:\n0 | 'n': Stand\n1 | 'h': Hit\n--------------\n3 | 'd': Double-Down\n4 | 'c': Surrender\n").strip().lower()
            else:
                action = input("Available actions:\n0 | 'n': Stand\n1 | 'h': Hit\n--------------\n--------------------\n4 | 'c': Surrender\n").strip().lower()
            return PlayerAction.from_input(action, can_split=can_split, can_dd=can_dd)
        except ValueError:
            print("Invalid input. Please enter a valid action.")


class Game:
    def __init__(self, num_decks, num_players, auto, auto_balance, auto_bet):
        self.num_decks = num_decks
        self.deck = [value + suit for suit in suits for value in values] * num_decks
        random.shuffle(self.deck)
        self.num_players = num_players
        self.auto = auto
        self.auto_bet = auto_bet
        self.played_cards = {value: 0 for value in values}
        if self.auto:
            self.players = [Player(player_num=num+1, balance=auto_balance) for num in range(num_players)]
        else:
            self.players = [Player(player_num=num+1) for num in range(num_players)]
        self.dealer = Dealer()
    
    def reset(self):
        for player in self.players:
            player.reset()
        self.dealer.reset()

    def deal_card(self):
        if not self.deck:
            return None  # No cards left to deal
        
        card = self.deck.pop()
        card_value = card[0]
        self.played_cards[card_value] += 1

        return card

    def initial_deal(self):
        for _ in range(2):
            for player in self.players:
                player.add_card(self.deal_card())
            self.dealer.add_card(self.deal_card())

    def deck_reshuffle_check(self):
        if len(self.deck) < self.num_players * 6:
            self.deck = [value + suit for suit in suits for value in values] * self.num_decks
            random.shuffle(self.deck)

    def distribute_chips(self):
        for player in self.players:
            while True:
                try:
                    acc_bal = round(float(input(f"Player {player.player_num}, Fund your account: ")), 2)
                    if acc_bal > 0:
                        player.set_balance(acc_bal)
                        break
                    else:
                        print('Cannot request negative balance')
                except ValueError:
                    print(f"Invalid account amount. Please enter a valid amount.")

    def collect_bets(self, automatic):
        if automatic:
            for player in self.players:
                player.place_bet(self.auto_bet)
        else:
            for player in self.players:
                while True:
                    try:
                        bet = round(float(input(f"Player {player.player_num} balance: {format_amount(player.balance)}\nBet: ")), 2)
                        player.place_bet(bet)

                        print(f"Player {player.player_num} | Balance: {format_amount(player.balance)} | Bet: {format_amount(player.bet_value[player.current_hand_index])}\n")
                        time.sleep(0.5)
                        break

                    except ValueError as e:
                        print(f"Invalid bet amount: {e}. Please enter a valid amount.")

    def print_hands(self, player_index, show_dealers_second_card=False, as_double_down=False):
        clear_screen()

        # Dealer's hand
        print_centered('Dealer')
        if show_dealers_second_card:
            print_cards_side_by_side(self.dealer.card_list[0])
            print_centered(f'Total: {self.dealer.card_sum[0]}\n')
        else:
            print_cards_side_by_side(self.dealer.card_list[0][:-1] + ['  '])
            print_centered(f'Visible Total: {self.dealer.partial_sum(len(self.dealer.card_list[0]) - 1)}\n')
        
        # Players' hands
        if self.players[player_index].num_hands > 1:
            print_centered(f'Player {player_index + 1} | Hand {self.players[player_index].current_hand_index+1} of {self.players[player_index].num_hands}')
        else:
            print_centered(f'Player {player_index + 1}')
        if as_double_down:
            print_cards_side_by_side(self.players[player_index].card_list[self.players[player_index].current_hand_index][:-1] + ['  '])
            print_centered(f'Visible Total: {self.players[player_index].partial_sum(len(self.players[player_index].card_list[self.players[player_index].current_hand_index]) - 1)}\
 | Bet: {format_amount(self.players[player_index].bet_value[self.players[player_index].current_hand_index])}')
        else:
            print_cards_side_by_side(self.players[player_index].card_list[self.players[player_index].current_hand_index])
            print_centered(f'Total: {self.players[player_index].card_sum[self.players[player_index].current_hand_index]} | Bet: {format_amount(self.players[player_index].bet_value[self.players[player_index].current_hand_index])}')

    def inspect_hands(self):
        while True:
            try:
                if self.num_players > 1:
                    next_action = input('Enter a player to inspect, or zero to return: ').strip()
                else:
                    next_action = '1'

                if not next_action.isdigit():
                    raise ValueError("Input must be a numeric value.")
                
                next_action = int(next_action) - 1

                if next_action == -1:
                    break
                
                if next_action < 0 or next_action >= len(self.players):
                    raise IndexError("Player index is out of range.")
                
                # If no exceptions are raised, print the player's hands
                self.print_hands(player_index=next_action, show_dealers_second_card=True)
                print(self.players[next_action])
            
                if self.num_players == 1:
                    break

            except (ValueError, IndexError) as e:
                print(f"Error: {e}")

    def play_game(self):
        continue_play = True
        if not self.auto:
            self.distribute_chips()
        while continue_play:
            clear_screen()
            self.collect_bets(automatic=self.auto)
            self.initial_deal()

            dealer_blackjack = False
            if self.dealer.check_possible_blackjack():
                self.print_hands(player_index=0)
                time.sleep(0.8)
                print_centered('Dealer checking for Blackjack')
                time.sleep(0.8)
                
                if self.dealer.has_blackjack():
                    dealer_blackjack = True
                    self.print_hands(player_index=0, show_dealers_second_card=True)
                    print_centered('Dealer has Blackjack. Everyone loses.')
                    time.sleep(1)
                else:
                    print_centered('Dealer does NOT have Blackjack.')
                    time.sleep(0.8)

            # Players' turns
            if not dealer_blackjack:
                for player in self.players:

                    # visualize player cards
                    self.print_hands(player_index=player.player_num-1)
                    
                    while player.current_hand_index < player.num_hands:

                        self.print_hands(player_index=player.player_num-1)
                        
                        if player.card_sum[player.current_hand_index] == 21:
                            player.set_flag('is_blackjack', True)
                            time.sleep(0.8)
                            print('\n')
                            print_centered('YOU GOT BLACKJACK')
                            time.sleep(0.8)

                        action = PlayerAction.STAND if player.get_flag('is_blackjack') else get_player_action(available_actions=player.get_available_actions())

                        if action == PlayerAction.DOUBLE_DOWN:
                            player.double_down_bet()
                            player.add_card(self.deal_card())
                            self.print_hands(player_index=player.player_num-1, as_double_down=True)

                            time.sleep(0.8)
                            print_centered('You doubled down')
                            time.sleep(0.8)
                            # skip further player querry
                            action = PlayerAction.STAND

                        while True:

                            if action == PlayerAction.STAND:
                                player.current_hand_index += 1
                                break

                            elif action == PlayerAction.HIT:
                                player.add_card(self.deal_card())
                                self.print_hands(player_index=player.player_num-1)
                                if player.is_bust() or player.card_sum[player.current_hand_index] == 21:
                                    time.sleep(0.8)
                                    player.current_hand_index += 1
                                    break
                                else:
                                    action = get_player_action(available_actions=player.get_available_actions())

                            elif action == PlayerAction.SPLIT:
                                player.split_hand(self.deal_card(), self.deal_card())
                                self.print_hands(player_index=player.player_num-1)
                                time.sleep(1)
                                print_centered(f'You split your pair. Dealing two additional cards. You put up another bet for your second hand.')
                                time.sleep(1.6)
                                self.print_hands(player_index=player.player_num-1)
                                break

                            else: # elif action == PlayerAction.SURRENDER:
                                player.surrender()
                                self.print_hands(player_index=player.player_num-1)
                                time.sleep(0.8)
                                print_centered('You surrendered. Half your bet is returned')
                                time.sleep(0.8)
                                player.current_hand_index+=1
                                break
                    
                    player.current_hand_index = 0

            # Dealer's turn

            # visualize player cards (reveal dealer's second card)
            self.print_hands(player_index=0, show_dealers_second_card=True)

            while self.dealer.should_hit():
                time.sleep(0.8)
                self.dealer.add_card(self.deal_card())
                self.print_hands(player_index=0, show_dealers_second_card=True)

            # Determine results and award winnings
            dealer_sum = self.dealer.card_sum[0]

            for player in self.players:
                player.current_hand_index = 0
                if player.num_hands == 1:
                    if player.get_flag('is_blackjack') and not dealer_blackjack:
                        player.win_blackjack()
                        print(f'Player {player.player_num}: BLACKJACK | {player.card_sum[0]} | {self.dealer.card_sum[0]} | Win 1.5x bet.')
                    elif player.get_flag('is_surrendered'):
                        # bet already managed during turn
                        print(f"Player {player.player_num}: SURRENDER | {player.card_sum[0]} | {self.dealer.card_sum[0]} | Lose half original bet.")
                    elif player.is_bust():
                        player.loss()
                        print(f'Player {player.player_num}: YOU LOSE  | {player.card_sum[0]} | {self.dealer.card_sum[0]} |')
                    elif self.dealer.is_bust() or player.card_sum[0] > dealer_sum:
                        player.win()
                        print(f'Player {player.player_num}: YOU WIN   | {player.card_sum[0]} | {self.dealer.card_sum[0]} |')
                    elif player.card_sum[0] < dealer_sum:
                        player.loss()
                        print(f'Player {player.player_num}: YOU LOSE  | {player.card_sum[0]} | {self.dealer.card_sum[0]} |')
                    else:
                        player.push()
                        print(f"Player {player.player_num}: PUSH      | {player.card_sum[0]} | {self.dealer.card_sum[0]} | Bet returned")
                else: # a split has occurred
                    print(f"Player {player.player_num}: SPLIT DECK RESULTS:")
                    while player.current_hand_index < player.num_hands:
                        if player.get_flag('is_blackjack') and not dealer_blackjack:
                            player.win_blackjack()
                            print(f'\tHand {player.current_hand_index+1}: BLACKJACK | {player.card_sum[player.current_hand_index]} | {self.dealer.card_sum[0]} | Win 1.5x bet.')
                        elif player.get_flag('is_surrendered'):
                            # bet already managed during turn
                            print(f"\tHand {player.current_hand_index+1}: SURRENDER | {player.card_sum[player.current_hand_index]} | {self.dealer.card_sum[0]} | Lose half original bet.")
                        elif player.is_bust():
                            player.loss()
                            print(f'\tHand {player.current_hand_index+1}: YOU LOSE  | {player.card_sum[player.current_hand_index]} | {self.dealer.card_sum[0]} |')
                        elif self.dealer.is_bust() or player.card_sum[player.current_hand_index] > dealer_sum:
                            player.win()
                            print(f'\tHand {player.current_hand_index+1}: YOU WIN   | {player.card_sum[player.current_hand_index]} | {self.dealer.card_sum[0]} |')
                        elif player.card_sum[player.current_hand_index] < dealer_sum:
                            player.loss()
                            print(f'\tHand {player.current_hand_index+1}: YOU LOSE  | {player.card_sum[player.current_hand_index]} | {self.dealer.card_sum[0]} |')
                        else:
                            player.push()
                            print(f"\tHand {player.current_hand_index+1}: PUSH      | {player.card_sum[player.current_hand_index]} | {self.dealer.card_sum[0]} | Bet returned")
                        player.current_hand_index += 1
                    player.current_hand_index = 0

            while True:
                user_input = input('Play again? [i for inspect hands] ').strip().lower()
                if user_input == 'i':
                    self.inspect_hands()
                elif user_input in ['1', 'y']:
                    continue_play = True
                    break
                else:
                    continue_play = False
                    break
            
            self.deck_reshuffle_check()
            self.reset()

        clear_screen()


if __name__ == '__main__':
    clear_screen()
    while True:
        try:
            user_input = input('How many players [1:4]: ').strip()

            inputs = user_input.split()
            num_players = int(inputs[0])

            # Check if num_players is within the valid range
            if num_players < 1 or num_players > 4:
                raise ValueError("Number of players must be between 1 and 4.")

            if len(inputs) == 1:
                auto_mode = False
                balance_val = None
                bet_val = None
                break
            elif len(inputs) == 3:
                auto_mode = True
                balance_val = round(float(inputs[1]), 2)
                bet_val = round(float(inputs[2]), 2)
                break
            else:
                raise SyntaxError("Incorrect format. Please use [ num_players ] or [ num_players, balance_val, bet_val ] syntax for automatic play.")
        except ValueError as e:
            print(f"Error: {e}")
        except IndexError:
            print("Invalid input. Please provide all required parameters.")
        except SyntaxError as e:
            print(f"Error: {e}")
    clear_screen()
    game = Game(num_decks=6, num_players=num_players, auto=auto_mode, auto_balance=balance_val, auto_bet=bet_val)
    game.play_game()
